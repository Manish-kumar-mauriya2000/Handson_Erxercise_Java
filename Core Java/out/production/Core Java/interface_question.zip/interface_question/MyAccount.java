package interface_question;

import interface_question.bankImpl.FDAcc;
import interface_question.bankImpl.HousingLoanAccount;
import interface_question.bankImpl.PersonalLoanAcc;
import interface_question.bankImpl.SavingsAcc;
import interface_question.bank.Account;
import interface_question.bank.AccountDetails;
import interface_question.bank.DepositAcc;
import interface_question.bank.LoanAcc;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyAccount {
    static Logger logger = Logger.getLogger(MyAccount.class.getName());
    public static void main(String[] args){
        List<AccountDetails> savingDetails=new ArrayList<>();
        List<AccountDetails> fdDetails=new ArrayList<>();
        List<AccountDetails> personalLoanDetails=new ArrayList<>();
        List<AccountDetails> housingLoanDetails=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        String msgName="Enter your name : ";
        String msgAddress="Enter your address : ";
        String msgPhone="Enter your phone no : ";
        String msgAccontNo="Enter Account No : ";

        int accountNo=1;
        while(true) {
            logger.info("\n=======================================\nEnter your option\n1.create Account\n2.Already have account\n3.Exit\n========================================");
            int option = sc.nextInt();
            if (option == 1) {
                logger.log(Level.INFO,"Your account no is created :{0} ",accountNo);
                logger.info("Enter choice\n1.Saving\n2.Fixed Deposit account:\n3.personal Loan\n4.Housing Loan ");
                int choice = sc.nextInt();
                if (choice == 1) {
                    logger.info(msgName);
                    String name = sc.next();
                    logger.info(msgAddress);
                    String address = sc.next();
                    logger.info(msgPhone);
                    int phoneNo = sc.nextInt();
                    logger.info("Enter your initial amount to deposit : ");
                    double balance = sc.nextInt();
                    savingDetails.add(new SavingsAcc(name, address, "Savings Account", phoneNo, balance, accountNo) {
                    });
                    Account account = new SavingsAcc();
                    account.createAcc(accountNo);

                } else if (choice == 2) {
                    logger.info(msgName);
                    String name = sc.next();
                    logger.info(msgAddress);
                    String address = sc.next();
                    logger.info(msgPhone);
                    int phoneNo = sc.nextInt();
                    logger.info("Enter your initial amount to deposit : ");
                    double balance = sc.nextInt();
                    fdDetails.add(new FDAcc(name, address, "fixed deposit Account", phoneNo, balance, accountNo));
                    Account account = new FDAcc();
                    account.createAcc(accountNo);

                } else if (choice == 3) {
                    logger.info(msgName);
                    String name = sc.next();
                    logger.info(msgAddress);
                    String address = sc.next();
                    logger.info(msgPhone);
                    int phoneNo = sc.nextInt();
                    logger.info("Enter principal : ");
                    double principal = sc.nextInt();
                    personalLoanDetails.add(new PersonalLoanAcc(name, address, "Personal loan account", phoneNo, principal, accountNo));
                    Account account = new PersonalLoanAcc();
                    account.createAcc(accountNo);

                } else if (choice == 4) {
                    logger.info(msgName);
                    String name = sc.next();
                    logger.info(msgAddress);
                    String address = sc.next();
                    logger.info(msgPhone);
                    int phoneNo = sc.nextInt();
                    logger.info("Enter principal : ");
                    double principal = sc.nextInt();
                    housingLoanDetails.add(new HousingLoanAccount(name, address, "Housing loan account", phoneNo, principal, accountNo));
                    Account account = new HousingLoanAccount();
                    account.createAcc(accountNo);

                }
                accountNo = accountNo + 1;
            } else if (option == 2) {
                logger.info("\n==========================================\nEnter choice.....\n1.savings account\n2.Fixed Deposit account\n3.personal loan account\n4.housing Loan account \n==========================================\n ");
                int choice = sc.nextInt();
                if (choice == 1) {
                    logger.info("\nSelect your option.....\n1.withdraw\n2.deposit\n3.balance\n4.Back to Home");
                    int val = sc.nextInt();
                    if (val == 1) {
                        logger.info(msgAccontNo);
                        int acctno = sc.nextInt();
                        logger.info("Enter withdraw Amount : ");
                        int withdrawAmount = sc.nextInt();
                        for (AccountDetails list : savingDetails) {
                            if (acctno == list.getAccountNo()) {
                                DepositAcc account = new SavingsAcc();
                                list.setBalance(account.withdraw(list.getBalance(), withdrawAmount));

                            }
                        }

                    } else if (val == 2) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        logger.info("Enter deposit Amount : ");
                        int depositAmount = sc.nextInt();
                        for (AccountDetails list : savingDetails) {
                            if (accNo == list.getAccountNo()) {
                                DepositAcc account = new SavingsAcc();
                                list.setBalance(account.deposit(list.getBalance(), depositAmount));
                            }
                        }
                    } else if (val == 3) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : savingDetails) {
                            if (accNo == list.getAccountNo()) {
                                DepositAcc account = new SavingsAcc();
                                account.getBalance(list.getBalance());
                            }
                        }
                    } else if (val == 4) {
                        logger.info("Home screen!!!!");
                    }
                } else if (choice == 2) {
                    logger.info("\nSelect your option\n1.withdraw\n2.deposit\n3.balance\n4.Back to home");
                    int val = sc.nextInt();
                    if (val == 1) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        logger.info("Enter withdraw Amount : ");
                        int withdrawAmount = sc.nextInt();
                        for (AccountDetails list : fdDetails) {
                            if (accNo == list.getAccountNo()) {
                                DepositAcc account = new FDAcc();
                                list.setBalance(account.withdraw(list.getBalance(), withdrawAmount));

                            }
                        }
                    } else if (val == 2) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        logger.info("Enter deposit Amount : ");
                        int depositAmount = sc.nextInt();
                        for (AccountDetails list : fdDetails) {
                            if (accNo == list.getAccountNo()) {
                                DepositAcc account = new FDAcc();
                                list.setBalance(account.deposit(list.getBalance(), depositAmount));

                            }
                        }
                    } else if (val == 3) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : fdDetails) {
                            if (accNo == list.getAccountNo()) {
                                DepositAcc account = new FDAcc();
                                account.getBalance(list.getBalance());

                            }
                        }
                    } else if (val == 4) {
                        logger.info("Home screen!!!");
                    }
                } else if (choice == 3) {
                    logger.info("\nSelect your option\n1.Repay Interest\n2.Repay partial interest\n3.Repay Principal\n4.Back to Home ");
                    int val = sc.nextInt();
                    if (val == 1) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : personalLoanDetails) {
                            if (accNo == list.getAccountNo()) {
                                LoanAcc account = new PersonalLoanAcc();
                                account.payInterest();
                            }
                        }
                    } else if (val == 2) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : personalLoanDetails) {
                            if (accNo == list.getAccountNo()) {
                                LoanAcc account = new PersonalLoanAcc();
                                account.payPartialPrincipal();
                            }
                        }
                    } else if (val == 3) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : personalLoanDetails) {
                            if (accNo == list.getAccountNo()) {
                                LoanAcc account = new PersonalLoanAcc();
                                account.repayPrincipal();

                            }
                        }
                    } else if (val == 4) {
                        logger.info("Home screen!!!");
                    }
                } else if (choice == 4) {
                    logger.info("\nSelect your option\n1.Repay Interest\n2.Repay partial interest\n3.Repay Principal\n4.Back to home ");
                    int val = sc.nextInt();
                    if (val == 1) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : housingLoanDetails) {
                            if (accNo == list.getAccountNo()) {
                                LoanAcc account = new HousingLoanAccount();
                                account.payInterest();
                            }
                        }
                    } else if (val == 2) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();
                        for (AccountDetails list : housingLoanDetails) {
                            if (accNo == list.getAccountNo()) {
                                LoanAcc account = new HousingLoanAccount();
                                account.payPartialPrincipal();
                            }
                        }
                    } else if (val == 3) {
                        logger.info(msgAccontNo);
                        int accNo = sc.nextInt();

                        for (AccountDetails list : housingLoanDetails) {
                            if (accNo == list.getAccountNo()) {
                                LoanAcc account = new HousingLoanAccount();
                                account.repayPrincipal();

                            }
                        }
                    } else if (val == 4) {
                        logger.info("Home screen!!!!");
                    }
                }
            } else {
                logger.info("Thank you!!! visit again............");
                break;
            }
        }
    }

}

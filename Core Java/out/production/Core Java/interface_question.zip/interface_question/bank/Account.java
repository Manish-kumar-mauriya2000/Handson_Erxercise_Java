package interface_question.bank;

public interface Account {
    public static final String savingAccount = "Savings";
    public static final String fixedAccount = "Fixed";
    public static final String personalLoanAccount = "PersonalLoan";
    public static final String housingLoanAccount = " HousingLoan";

    public void createAcc(int acctNo);

}

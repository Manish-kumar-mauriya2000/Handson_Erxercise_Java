package interface_question.bank;

public interface Interest {
    double savingIntrest = 5.6;
    double fixedIntrest = 3.5;
    double personalLoanInterst = 2.8;
    double housingLoanInterst = 4.5;

    public double calcInt(double dt);

}

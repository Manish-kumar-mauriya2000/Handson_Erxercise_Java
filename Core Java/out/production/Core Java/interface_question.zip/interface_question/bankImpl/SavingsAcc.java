package interface_question.bankImpl;
import interface_question.bank.AccountDetails;
import interface_question.bank.CreditInterest;
import interface_question.bank.DepositAcc;

public class SavingsAcc extends AccountDetails implements DepositAcc, CreditInterest {

    public SavingsAcc(String name, String address, String accountType, int phoneNo, double balance,int accountNo) {
        super(name,address, accountType, phoneNo, (int) balance,accountNo);
    }

    public SavingsAcc() {
    }

    @Override
    public void createAcc(int acctNo) {
        System.out.println("Saving Account created : "+acctNo);
    }

    @Override
    public double withdraw(double balance, int withdrawAmt) {
        if(balance<withdrawAmt){
            System.out.println("Insufficient balance!!!");

        }
        else {
            System.out.println("Withdraw successful...");
            System.out.println("After withdraw your balance is : " + (balance - withdrawAmt));
        }

        return balance;
    }

    @Override
    public double deposit(double balance, int depositAmt) {
        if(depositAmt==0){
            System.out.println("Amount 0 is not allowed to deposit!!!!");
        }
        else{
            balance=balance+depositAmt;
            System.out.println("After deposit total balance : "+balance);
        }
        return balance;
    }

    @Override
    public double getBalance(double balance) {
        System.out.println("Balance : "+balance);
        return balance;
    }

    @Override
    public double addMonthlyInt(double money) {
        return money+((money*5.6*(1/12))/100);
    }

    @Override
    public double addHalfYrlyInt(double money) {
        return money+((money*5.6*(6/12))/100);
    }

    @Override
    public double addAnnualInt(double money) {
        return money+((money*5.6*(1/12))/100);
    }

    @Override
    public double calcInt(double money) {
        System.out.println((money*5.6*1)/100);
        return money;
    }
}

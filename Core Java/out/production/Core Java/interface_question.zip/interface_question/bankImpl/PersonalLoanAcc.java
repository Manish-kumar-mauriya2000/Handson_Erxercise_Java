package interface_question.bankImpl;

import interface_question.bank.AccountDetails;
import interface_question.bank.DebitInterest;
import interface_question.bank.LoanAcc;

public class PersonalLoanAcc extends AccountDetails implements LoanAcc, DebitInterest {
    public PersonalLoanAcc() {
    }
    public PersonalLoanAcc(String name, String address, String accountType, int phoneNo, double balance,int accountNo) {
        super(name, address, accountType, phoneNo, (int)balance,accountNo);
    }


    @Override
    public void createAcc(int acctNo) {
        System.out.println("Personal Loan Account created : "+acctNo);
    }

    @Override
    public double deductMonthlyInt(double money) {
        return money-(money*2.2*(1/12));

    }

    @Override
    public double deductHalfYrlyInt(double money) {
        return money-(money*2.2*(6/12));
    }

    @Override
    public double deductAnnualInt(double money) {
        return money-(money*2.2*(1));
    }

    @Override
    public double calcInt(double dt) {
        return (dt*2.2*1)/100;
    }

    @Override
    public void repayPrincipal() {
        System.out.println("Repay principal..");
    }

    @Override
    public void payInterest() {
        System.out.println("Pay Interest paid....");
    }

    @Override
    public void payPartialPrincipal() {
        System.out.println("Pay partial principal paid....");
    }
}

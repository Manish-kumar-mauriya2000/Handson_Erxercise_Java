package exception_handling;

import java.util.LinkedList;

public class Exercise4 {
    public static void main(String[] args){
        LinkedList<Integer> list = new LinkedList<>();
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        System.out.println("List :"+list);
        LinkedList clone = new LinkedList<>();
        clone= (LinkedList) list.clone();
        System.out.println("Clone List : "+clone);
    }
}
